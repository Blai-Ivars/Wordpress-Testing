<?php
/**
 * Displays footer site info
 */

?>
<div class="site-info-tgen">
	Built with <a href="https://themesgenerator.com/" title="Create & edit Wordpress Themes">WordPress Themes Generator</a>
</div><!-- .site-info -->
