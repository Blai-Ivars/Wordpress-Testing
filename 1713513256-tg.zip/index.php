<?php
/**
 * The main template file
 */

global $post;  
$todoslosthememods=get_theme_mods();
//print_r($todoslosthememods); 
$customheader=0;
foreach($todoslosthememods as $key =>
 $value)
	{
	   if(preg_match('/^nt_featured_pages/', $key))
	   {
		   if ($customheader==0){
				$menunumber=str_replace("nt_featured_pages","",$key);						
				if (in_array("123454321", $value)) { //Assigned to homepage
					get_header("custom$menunumber");
					$customheader=1;
				}
				if (in_array("0", $value)) { //Assigned to no pages
					//get_header("custom$menunumber");
					$customheader=0;
				}
		   } 			
	   }
	}	
if ($customheader==0) get_header(); 
?>


<div class="wrap">

	<div id="primary" class="content-area">

		<main id="main" class="site-main" role="main">


			
<div id="ihw5b" class="C1">
<div id="ip576" class="C1_titol">
<b>
The Simpsons</b>
</div>
<div id="ihjkqz">
<span id="tgimg-1">
<img <?php if( get_theme_mod( "tgimg-1") != "" ) {echo "src='".get_theme_mod( "tgimg-1")."'";} else {echo " src='".get_template_directory_uri()."/images/Simp1-aa5.avif'";} ?>
 id="ipunun"  class="C1_imatge" />
</span>
</div>
</div>
<div id="irtu48">
<div id="i6zxvh" class="C3">
<span id="tgimg-2">
<img <?php if( get_theme_mod( "tgimg-2") != "" ) {echo "src='".get_theme_mod( "tgimg-2")."'";} else {echo " src='".get_template_directory_uri()."/images/2-e2b.jpg'";} ?>
 id="ib3a32"  class="C3_imatge" />
</span>
</div>
<div id="i1i4nf" class="C3">
<span id="tgimg-3">
<img <?php if( get_theme_mod( "tgimg-3") != "" ) {echo "src='".get_theme_mod( "tgimg-3")."'";} else {echo " src='".get_template_directory_uri()."/images/1-e70.avif'";} ?>
 id="ijvcrg"  class="C3_imatge" />
</span>
</div>
<div id="i6ms64" class="C3">
<span id="tgimg-4">
<img <?php if( get_theme_mod( "tgimg-4") != "" ) {echo "src='".get_theme_mod( "tgimg-4")."'";} else {echo " src='".get_template_directory_uri()."/images/3-f07.jpg'";} ?>
 id="irywmp"  class="C3_imatge" />
</span>
</div>
<div id="i4pvvr" class="C3">
<span id="tgimg-5">
<img <?php if( get_theme_mod( "tgimg-5") != "" ) {echo "src='".get_theme_mod( "tgimg-5")."'";} else {echo " src='".get_template_directory_uri()."/images/5-2a4.avif'";} ?>
 id="isph3t"  class="C3_imatge" />
</span>
</div>
<div id="imxpd5" class="C3">
<span id="tgimg-6">
<img <?php if( get_theme_mod( "tgimg-6") != "" ) {echo "src='".get_theme_mod( "tgimg-6")."'";} else {echo " src='".get_template_directory_uri()."/images/7-e47.jpg'";} ?>
 id="i59288"  class="C3_imatge" />
</span>
</div>
<div id="iqkzh1" class="C3">
<span id="tgimg-7">
<img <?php if( get_theme_mod( "tgimg-7") != "" ) {echo "src='".get_theme_mod( "tgimg-7")."'";} else {echo " src='".get_template_directory_uri()."/images/8-000.png'";} ?>
 id="ipze4o"  class="C3_imatge" />
</span>
</div>
<div id="ir4xez">
</div>
</div>
<div id="i1kyl" class="trailer_blog">
<div id="ie2kd" class="C4">
<iframe allowfullscreen="allowfullscreen" id="iwk80q" src="https://www.youtube.com/embed/XPG0MqIcby8?&loop=1&playlist=XPG0MqIcby8&modestbranding=1">
</iframe>
</div>
<div id="ial3h" class="C5">
</div>
<div id="i2w8y">
</div>
</div>


		</main>
<!-- #main -->

	</div>
<!-- #primary -->

	<?php get_sidebar(); ?>

</div>
<!-- .wrap -->


<?php 
 $customfooter=0;
 foreach($todoslosthememods as $key =>
 $value)
	{
	   if(preg_match('/^nt_featured_Foopages/', $key))
	   {
		   if ($customfooter==0){
				$menunumber=str_replace("nt_featured_Foopages","",$key);			
				$idpageactual=$post->
ID;			
				if (in_array($idpageactual, $value)) { //Assigned to this page
					get_footer("custom$menunumber");
					$customfooter=1;
				}
				if (in_array("123454321", $value)) { //Assigned to all pages
					get_footer("custom$menunumber");
					$customfooter=1;
				}
				if (in_array("0", $value)) { //Assigned to no pages
					//get_footer("custom$menunumber");
					$customfooter=0;
				}
		   } 			
	   }
	}	
if ($customfooter==0) get_footer("");