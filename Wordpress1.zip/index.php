<?php
/**
 * The main template file
 */

global $post;  
$todoslosthememods=get_theme_mods();
//print_r($todoslosthememods); 
$customheader=0;
foreach($todoslosthememods as $key =>
 $value)
	{
	   if(preg_match('/^nt_featured_pages/', $key))
	   {
		   if ($customheader==0){
				$menunumber=str_replace("nt_featured_pages","",$key);						
				if (in_array("123454321", $value)) { //Assigned to homepage
					get_header("custom$menunumber");
					$customheader=1;
				}
				if (in_array("0", $value)) { //Assigned to no pages
					//get_header("custom$menunumber");
					$customheader=0;
				}
		   } 			
	   }
	}	
if ($customheader==0) get_header(); 
?>


<div class="wrap">

	<div id="primary" class="content-area">

		<main id="main" class="site-main" role="main">


			
<div id="ihw5b" class="C1">
<div id="ip576" class="C1_titol">
<span id="tgtext-1">
<?php if( get_theme_mod( "tgtext-1") != "" ) {echo get_theme_mod( "tgtext-1");} else {echo "The Simpsons";} ?>
</span>
</div>
<div data-gjs='navbar' class='navbar' style='overflow: visible;'>
 <div class='navbar-container containermymenu2' style='overflow: visible;'>
 <div class='navbar-burger mobilemymenu2' style='overflow: visible;'>
 <div class='navbar-burger-line'>
 </div>
 <div class='navbar-burger-line'>
 </div>
 <div class='navbar-burger-line'>
 </div>
 <div style='clear:both;'>
</div>
 </div>
 <div data-gjs='navbar-items' class='navbar-items-c itemsmymenu2' style='overflow: visible;'>
 <nav data-gjs='navbar-menu' class='navbar-menu' style='overflow: visible;'>
<?php if ( has_nav_menu( 'menu2' ) ) { wp_nav_menu(array('menu_class' =>
 'menu mymenu2', 'walker' =>
 new Excerpt_Walker(), 'container' =>
 false, 'theme_location' =>
 'menu2', 'menu' =>
 'primary')); } else { echo '<span style=\'color:#9c9c9c;\'>
Please, go to <strong>
Customize ->
 Menus ->
 Locations</strong>
 and assign a menu to the <strong>
menu2</strong>
 menu location</span>
';}; ?>
<div style='clear:both;'>
</div>
 </nav>
 <div style='clear:both;'>
</div>
</div>
 <div style='clear:both;'>
</div>
</div>
 <div style='clear:both;'>
</div>
</div>
<div id="i7gik" class="C1_imatge">
</div>
</div>
<div id="irtu48">
<div id="i6zxvh">
</div>
<div id="i1i4nf">
</div>
<div id="i6ms64">
</div>
<div id="i4pvvr">
</div>
<div id="imxpd5">
</div>
<div id="iqkzh1">
</div>
<div id="ir4xez">
</div>
</div>
<div id="i1kyl" class="trailer_blog">
<div id="ie2kd" class="C4">
<iframe allowfullscreen="allowfullscreen" id="iwk80q" src="https://www.youtube.com/embed/XPG0MqIcby8?&loop=1&playlist=XPG0MqIcby8&modestbranding=1">
</iframe>
</div>
<div id="ial3h" class="C5">
</div>
<div id="i2w8y">
</div>
</div>


		</main>
<!-- #main -->

	</div>
<!-- #primary -->

	<?php get_sidebar(); ?>

</div>
<!-- .wrap -->


<?php 
 $customfooter=0;
 foreach($todoslosthememods as $key =>
 $value)
	{
	   if(preg_match('/^nt_featured_Foopages/', $key))
	   {
		   if ($customfooter==0){
				$menunumber=str_replace("nt_featured_Foopages","",$key);			
				$idpageactual=$post->
ID;			
				if (in_array($idpageactual, $value)) { //Assigned to this page
					get_footer("custom$menunumber");
					$customfooter=1;
				}
				if (in_array("123454321", $value)) { //Assigned to all pages
					get_footer("custom$menunumber");
					$customfooter=1;
				}
				if (in_array("0", $value)) { //Assigned to no pages
					//get_footer("custom$menunumber");
					$customfooter=0;
				}
		   } 			
	   }
	}	
if ($customfooter==0) get_footer("");