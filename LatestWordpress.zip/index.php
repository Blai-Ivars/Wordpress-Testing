<?php
/**
 * The main template file
 */

global $post;  
$todoslosthememods=get_theme_mods();
//print_r($todoslosthememods); 
$customheader=0;
foreach($todoslosthememods as $key =>
 $value)
	{
	   if(preg_match('/^nt_featured_pages/', $key))
	   {
		   if ($customheader==0){
				$menunumber=str_replace("nt_featured_pages","",$key);						
				if (in_array("123454321", $value)) { //Assigned to homepage
					get_header("custom$menunumber");
					$customheader=1;
				}
				if (in_array("0", $value)) { //Assigned to no pages
					//get_header("custom$menunumber");
					$customheader=0;
				}
		   } 			
	   }
	}	
if ($customheader==0) get_header(); 
?>


<div class="wrap">

	<div id="primary" class="content-area">

		<main id="main" class="site-main" role="main">


			
<div id="ihw5b" class="C1">
<div id="ip576" class="C1_titol">
<b>
The Simpsons</b>
</div>
<div data-gjs='navbar' class='navbar' style='overflow: visible;'>
 <div class='navbar-container containermymenu1' style='overflow: visible;'>
 <div class='navbar-burger mobilemymenu1' style='overflow: visible;'>
 <div class='navbar-burger-line'>
 </div>
 <div class='navbar-burger-line'>
 </div>
 <div class='navbar-burger-line'>
 </div>
 <div style='clear:both;'>
</div>
 </div>
 <div data-gjs='navbar-items' class='navbar-items-c itemsmymenu1' style='overflow: visible;'>
 <nav data-gjs='navbar-menu' class='navbar-menu' style='overflow: visible;'>
<?php if ( has_nav_menu( 'menu1' ) ) { wp_nav_menu(array('menu_class' =>
 'menu mymenu1', 'walker' =>
 new Excerpt_Walker(), 'container' =>
 false, 'theme_location' =>
 'menu1', 'menu' =>
 'primary')); } else { echo '<span style=\'color:#9c9c9c;\'>
Please, go to <strong>
Customize ->
 Menus ->
 Locations</strong>
 and assign a menu to the <strong>
menu1 menu</strong>
 location</span>
';}; ?>
<div style='clear:both;'>
</div>
 </nav>
 <div style='clear:both;'>
</div>
</div>
 <div style='clear:both;'>
</div>
</div>
 <div style='clear:both;'>
</div>
</div>
<div id="ihjkqz">
<span id="tgimg-1">
<img <?php if( get_theme_mod( "tgimg-1") != "" ) {echo "src='".get_theme_mod( "tgimg-1")."'";} else {echo " src='".get_template_directory_uri()."/images/Simp1-aa5.avif'";} ?>
 id="ipunun"  class="C1_imatge" />
</span>
</div>
</div>
<div id="irtu48">
<div id="i6zxvh" class="C3">
<span id="tgimg-2">
<img <?php if( get_theme_mod( "tgimg-2") != "" ) {echo "src='".get_theme_mod( "tgimg-2")."'";} else {echo " src='".get_template_directory_uri()."/images/2-e2b.jpg'";} ?>
 id="ib3a32"  class="C3_imatge" />
</span>
</div>
<div id="i1i4nf" class="C3">
<span id="tgimg-3">
<img <?php if( get_theme_mod( "tgimg-3") != "" ) {echo "src='".get_theme_mod( "tgimg-3")."'";} else {echo " src='".get_template_directory_uri()."/images/1-e70.avif'";} ?>
 id="ijvcrg"  class="C3_imatge" />
</span>
</div>
<div id="i6ms64" class="C3">
<span id="tgimg-4">
<img <?php if( get_theme_mod( "tgimg-4") != "" ) {echo "src='".get_theme_mod( "tgimg-4")."'";} else {echo " src='".get_template_directory_uri()."/images/3-f07.jpg'";} ?>
 id="irywmp"  class="C3_imatge" />
</span>
</div>
<div id="i4pvvr" class="C3">
<span id="tgimg-5">
<img <?php if( get_theme_mod( "tgimg-5") != "" ) {echo "src='".get_theme_mod( "tgimg-5")."'";} else {echo " src='".get_template_directory_uri()."/images/5-2a4.avif'";} ?>
 id="isph3t"  class="C3_imatge" />
</span>
</div>
<div id="imxpd5" class="C3">
<span id="tgimg-6">
<img <?php if( get_theme_mod( "tgimg-6") != "" ) {echo "src='".get_theme_mod( "tgimg-6")."'";} else {echo " src='".get_template_directory_uri()."/images/7-e47.jpg'";} ?>
 id="i59288"  class="C3_imatge" />
</span>
</div>
<div id="iqkzh1" class="C3">
<span id="tgimg-7">
<img <?php if( get_theme_mod( "tgimg-7") != "" ) {echo "src='".get_theme_mod( "tgimg-7")."'";} else {echo " src='".get_template_directory_uri()."/images/8-000.png'";} ?>
 id="ipze4o"  class="C3_imatge" />
</span>
</div>
<div id="ir4xez">
</div>
</div>
<div id="i1kyl" class="trailer_blog">
<div id="ie2kd" class="C4">
<iframe allowfullscreen="allowfullscreen" id="iwk80q" src="https://www.youtube.com/embed/XPG0MqIcby8?&loop=1&playlist=XPG0MqIcby8&modestbranding=1">
</iframe>
</div>
<div id="ial3h" class="C5">
<div id="theme-latest-post">
 <div style="clear:both;">
</div>
 <span id="latest_postz_name1">
</span>
 <div class="latestpostz-1">
 <?php if(( trim(get_theme_mod("latest_postz_name1")) != "default" )&&( trim(get_theme_mod("latest_postz_name1")) != "0" )) { $categorytoshow = get_theme_mod("latest_postz_name1"); $postcounttoshow = get_theme_mod("tglatest_post_count1"); if (empty($postcounttoshow)) $postcounttoshow=5; if (!empty($categorytoshow)) { if ($categorytoshow=="showallcategories") { $the_query1 = new WP_Query( array('posts_per_page' =>
 $postcounttoshow,'ignore_sticky_posts' =>
 1)); } else { $the_query1 = new WP_Query( array('category_name' =>
 "$categorytoshow",'posts_per_page' =>
 $postcounttoshow,'ignore_sticky_posts' =>
 1)); } if ( $the_query1->
have_posts() ) { while ( $the_query1->
have_posts() ) { $the_query1->
the_post(); ?>
<a href="<?php the_permalink();?>
" title="<?php the_title();?>
">
<div class="latest-post-container">
 <div class="latest-post-thumb">
<?php the_post_thumbnail();?>
</div>
 <div class="latest-post-content">
<div class="latest-post-title">
<?php the_title();?>
</div>
 <p>
<?php the_excerpt();?>
</p>
</div>
</div>
</a>
<?php } wp_reset_postdata(); }else { echo " __('No posts in this category')";}}else {echo "<p style=\"text-align:center;\">
Select a category to show its posts here using <strong>
customize</strong>
 menu</p>
";}} else {echo "<p style=\"text-align:center;\">
Select a category to show its posts here using <strong>
customize</strong>
 menu</p>
";} ?>
 </div>
 <div style="clear:both;">
</div>
 </div>
</div>
<div id="i2w8y">
</div>
</div>


		</main>
<!-- #main -->

	</div>
<!-- #primary -->

	<?php get_sidebar(); ?>

</div>
<!-- .wrap -->


<?php 
 $customfooter=0;
 foreach($todoslosthememods as $key =>
 $value)
	{
	   if(preg_match('/^nt_featured_Foopages/', $key))
	   {
		   if ($customfooter==0){
				$menunumber=str_replace("nt_featured_Foopages","",$key);			
				$idpageactual=$post->
ID;			
				if (in_array($idpageactual, $value)) { //Assigned to this page
					get_footer("custom$menunumber");
					$customfooter=1;
				}
				if (in_array("123454321", $value)) { //Assigned to all pages
					get_footer("custom$menunumber");
					$customfooter=1;
				}
				if (in_array("0", $value)) { //Assigned to no pages
					//get_footer("custom$menunumber");
					$customfooter=0;
				}
		   } 			
	   }
	}	
if ($customfooter==0) get_footer("");